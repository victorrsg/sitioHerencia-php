<?php
require_once('Animal.php');
class Perro extends Animal
{
    public function comer()
    {
        echo "<p>Perro comiendo huesos</p>";
    }
}