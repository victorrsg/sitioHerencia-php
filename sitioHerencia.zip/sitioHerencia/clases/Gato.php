<?php

require_once('Animal.php');
class Gato extends Animal
{

}