<?php
abstract class Animal      
{
    public function comer()
    {
        echo "<p>Animal comiendo (desde padre)</p>";
    }

    protected function dormir()
    {
        echo "<p>Animal durmiendo</p>";
    }
    
    public function usarProtectedPadre()
    {
        $this->dormir();
    }






}//cierra clase